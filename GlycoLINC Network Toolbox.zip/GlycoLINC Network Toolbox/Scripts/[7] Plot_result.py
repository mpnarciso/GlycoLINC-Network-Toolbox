# This code lets you extract the genes
# that have an effect with your gene 
# of interest.
# Code developed by Michelle P. Narciso

################################

# Import and load needed modules.
import pandas as pd
import matplotlib.pyplot as plt
import os
import stat
import platform
import subprocess

################################

# Specify your gene(s) of interest.
print("")
print("Specify your gene(s) of interest. Separate gene names with a space: ")
gene_interest = [str(x) for x in input().split()]

################################

# NUMERICAL ANALYSIS

################################

# Read gene ID to gene name reference.
dfnames = pd.read_csv("Gene_ID_reference.csv", index_col = 0)

# Read sets of important genes.
important_genes = pd.read_csv("[3] Declare_important_genes.csv")
set1 = [x for x in important_genes["Set_1"].tolist() if (x != 'nan') & (x in dfnames.index)]
set2 = [x for x in important_genes["Set_2"].tolist() if (x != 'nan') & (x in dfnames.index)]
if len(set1) > len(set2):
    set3 = set1
    set1 = set2
    set2 = set3
importantgenelist = gene_interest

# Plot the first five in the list
# of important genes.
dfrk4 = pd.read_csv("Numerical_analysis_output.csv", sep = ",", index_col = 0)
dfrk4.drop(dfrk4.columns[[-1, ]], axis = 1, inplace = True)
dfrk4.index.names = ['time']
dfrk4.columns = dfnames.index
dfrk4 = dfrk4.loc[:, importantgenelist]
dfrk4.reset_index(inplace = True)
num_plots = len(dfrk4.columns)
colormap = plt.cm.gist_ncar
fig = plt.figure()
ax = plt.subplot(111)
ax.set_title('$\\bf{No}$ $\\bf{Perturbation}$')
ax.set(xlabel="TIME", ylabel="Gene Expression Value")
for i in range(1, num_plots):
    line, = ax.plot(dfrk4.iloc[:, 0], dfrk4.iloc[:, i].values, label = dfrk4.columns[i])
box = ax.get_position()
ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
ax.legend(loc = 'upper center', bbox_to_anchor = (1.1, 1.0), fancybox = True, shadow = True, ncol = 1)
plt.show()

# Save plot.
fig.savefig("Plot_numerical_analysis.png", bbox_inches="tight")
print("Figure saved to 'Plot_numerical_analysis.png'.")  

################################

# PERTURBATION ANALYSIS

################################

dfreference = pd.read_csv("Gene_ID_reference.csv", index_col = 0)
genes = dfreference.index.tolist()

################################

# Get corresponding graph.
for n in gene_interest:
    m= dfreference.loc[dfreference.index == n, "Gene_ID"].iloc[0]
    for i in genes:    
        geneid = dfreference.loc[dfreference.index == i, "Gene_ID"].iloc[0]    
        dfrk4 = pd.read_csv("Perturbation_analysis_output_Gene" + str(geneid) + "_Means" + str(1) + ".csv", sep = ",", index_col = 0)    
        dfveuszinput = pd.DataFrame(index = dfrk4.index)    
        for j in range(1,16):        
            dfrk4 = pd.read_csv("Perturbation_analysis_output_Gene" + str(geneid) + "_Means" + str(j) + ".csv", sep = ",", index_col = 0)        
            dfveuszinput[str(j)] = dfrk4[dfrk4.columns[m-1]]        
        dfveuszinput.to_csv("Veusz_input_for_effect_of_" + str(i) + "_perturbation_to_" + str(n) + ".csv", header = False)
        print("For plotting outside Python such as Veusz, 'Veusz_input_for_effect_of_" + str(i) + "_perturbation_to_" + str(n) + ".csv' saved.")
        
        # Plot.
        dfveuszinput.index.names = ['time']
        dfveuszinput.reset_index(inplace = True)
        num_plots = len(dfveuszinput.columns)
        colormap = plt.cm.gist_ncar
        fig = plt.figure()
        ax = plt.subplot(111)
        ax.set_title("Effect of " + str(i) + " perturbation to " + str(n))
        ax.set(xlabel="TIME", ylabel= str(n) + " Expression Value")
        for j in range(1, num_plots):
            line, = ax.plot(dfveuszinput.iloc[:, 0], dfveuszinput.iloc[:, j].values, label = dfveuszinput.columns[j])
        box = ax.get_position()
        ax.set_position([box.x0, box.y0 + box.height * 0.1, box.width, box.height * 0.9])
        ax.legend(loc = 'upper center', bbox_to_anchor = (1.1, 1.0), fancybox = True, shadow = True, ncol = 1)
        plt.show()
        fig.savefig("Effect_of_" + str(i) + "_perturbation_to_" + str(n) + ".png", bbox_inches="tight")
        print("Figure saved to 'Effect_of_" + str(i) + "_perturbation_to_" + str(n) + ".png'.")
        
################################
        
# Hide perturbation analysis files: inputs and outputs.
if platform.system() == 'Darwin':
    st = os.stat(os.getcwd()+"/Shortest_path_input.csv")
    os.chflags(os.getcwd()+"/Shortest_path_input.csv", st.st_flags ^ stat.UF_HIDDEN) 
    st = os.stat(os.getcwd()+"/Gene_ID_reference.csv")
    os.chflags(os.getcwd()+"/Gene_ID_reference.csv", st.st_flags ^ stat.UF_HIDDEN)        
    for i in range(1,len(genes)+1):
        for j in range(1,16):
            st = os.stat(os.getcwd()+"/Perturbation_analysis_input_Gene"+str(i)+"_Means"+str(j)+".csv")
            os.chflags(os.getcwd()+"/Perturbation_analysis_input_Gene"+str(i)+"_Means"+str(j)+".csv", st.st_flags ^ stat.UF_HIDDEN)
            st = os.stat(os.getcwd()+"/Perturbation_analysis_output_Gene"+str(i)+"_Means"+str(j)+".csv")
            os.chflags(os.getcwd()+"/Perturbation_analysis_output_Gene"+str(i)+"_Means"+str(j)+".csv", st.st_flags ^ stat.UF_HIDDEN)
            
elif platform.system() == 'Windows' or platform.system() == 'win32' or platform.system() == 'win64':
    subprocess.check_call(["attrib","+H","Shortest_path_input.csv"])
    subprocess.check_call(["attrib","+H","Gene_ID_reference.csv"])
    for i in range(1,len(genes)+1):
        for j in range(1,16):
            subprocess.check_call(["attrib","+H","Perturbation_analysis_input_Gene"+str(i)+"_Means"+str(j)+".csv"])
            subprocess.check_call(["attrib","+H","Perturbation_analysis_output_Gene"+str(i)+"_Means"+str(j)+".csv"])

del dfreference, dfrk4, dfveuszinput, geneid, genes, j, num_plots, i, m, n