# This code finds the shortest path between
# two sets of genes. Uses Dijkstra's
# algorithm.
# Code developed by Michelle P. Narciso.

#################################

# Import and load needed modules.
import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
plt.rcParams.update({'figure.max_open_warning': 0})
import time
import os
import sys
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

#################################

# Start running time.
start_time = time.time()
print("")
print("Please wait.")

#################################

# Read input from previous script.
network_input = pd.read_csv("Shortest_path_input.csv", index_col=0)

# Read sets of important genes.
important_genes = pd.read_csv("[3] Declare_important_genes.csv")
set1 = [x for x in important_genes["Set_1"].tolist() if (x != 'nan') & (x in network_input['Gene1'].tolist())]
set2 = [x for x in important_genes["Set_2"].tolist() if (x != 'nan') & (x in network_input['Gene1'].tolist())]
if len(set1) > len(set2):
    set3 = set1
    set1 = set2
    if len(set1) == 0:
        print("")
        sys.exit("The gene(s) you specified in '[3] Declare_important_genes.csv' second column is(are) not present in the filtered data.")
    elif len(set2) == 0:
        print("")
        sys.exit("The gene(s) you specified in '[3] Declare_important_genes.csv' first column is(are) not present in the filtered data.")
if len(set1) == 0 and len(set2) == 0:
    print("")
    sys.exit("The gene(s) you specified in '[3] Declare_important_genes.csv' is(are) not present in the filtered data.")
elif len(set1) == 0:
    print("")
    sys.exit("The gene(s) you specified in '[3] Declare_important_genes.csv' first column is(are) not present in the filtered data.")
elif len(set2) == 0:
    print("")
    sys.exit("The gene(s) you specified in '[3] Declare_important_genes.csv' second column is(are) not present in the filtered data.")

# Read filtered data without correlation filter from
# previous script.
Etable=pd.read_csv("Filtered_data_without_correlation_filter.csv",index_col=0)

#################################

# List all genes from the input.
nodes = pd.concat([network_input.Gene1, network_input.Gene2]).unique()

#################################

# Implement Dijktra's algorithm.
dffinal=pd.DataFrame(columns = ['Gene', 'Path_length', 'Previous_gene'])
for g in set1:
    start = g
    current = start
    dftable = pd.DataFrame(columns = ['Gene', 'Path_length', 'Previous_gene'])
    dftable['Gene'] = nodes
    dftable['Path_length'] = 1000000
    dftable.loc[dftable['Gene'] == current, 'Path_length'] = 0
    visited = []
    unvisited = nodes.tolist()
    
    # Visit all nodes.
    while len(unvisited)!=0:
        neighborlist = set(network_input.loc[network_input['Gene1']==current]['Gene2'].tolist())-set(visited)
        for i in neighborlist:
            neighbordistance=dftable.loc[dftable['Gene'] == i, 'Path_length'].item()
            currentdistance=dftable.loc[dftable['Gene'] == current, 'Path_length'].item()
            if neighbordistance>currentdistance+1:
                dftable.loc[dftable['Gene'] == i, 'Path_length'] = currentdistance+1
                dftable.loc[dftable['Gene'] == i, 'Previous_gene'] = current
        visited.append(current)
        unvisited.remove(current)
        current=dftable.loc[dftable['Gene'].isin(unvisited)]
        if len(current.index)==0:
            break
        current=current[current['Path_length'] == min(current['Path_length'])].drop_duplicates(subset='Path_length').Gene.item()
        
    # Backtrack.
    for i in set2:
        dfdummy=pd.DataFrame(columns=dftable.columns)
        previous=dftable.loc[dftable['Gene'] == i].Previous_gene.item()
        dfdummy=dfdummy.append(dftable.loc[dftable['Gene'] == i])
        while start not in dfdummy.Previous_gene:
            dfdummy=dfdummy.append(dftable.loc[dftable['Gene'] == previous])
            if len(dftable.loc[dftable['Gene'] == previous].index)==0:
                break
            previous=dftable.loc[dftable['Gene'] == previous].Previous_gene.item()
        dfdummy=dfdummy.dropna()
        dfdum=dfdummy.copy()
        dfdum=dfdum.rename(columns={'Gene':'Gene2','Previous_gene':'Gene1'}).merge(network_input,on=['Gene1','Gene2'])
        if dfdum.shape[0] == 0:
            break
        dfpositive = dfdum[dfdum['Corr'] >= 0]
        dfnegative = dfdum[dfdum['Corr'] <= 0]
        G = nx.from_pandas_edgelist(dfdum, 'Gene1', 'Gene2')
        G.add_edges_from([tuple(x) for x in dfpositive[['Gene1', 'Gene2']].values],color='b')
        G.add_edges_from([tuple(x) for x in dfnegative[['Gene1', 'Gene2']].values],color='r')
        edges = G.edges()
        colors = [G[u][v]['color'] for u,v in edges]
        plt.figure()
        nx.draw(G, with_labels = True, edges=edges, edge_color=colors)#
        plt.savefig('Path_from_'+str(g)+'_to_'+str(i)+'.png', dpi = 300)
        dffinal=dffinal.append(dfdummy).drop_duplicates(keep='first')                                              

# Polish shortest path.
dfdummy=dffinal.rename(columns={'Gene':'Gene2','Previous_gene':'Gene1'}).merge(network_input,on=['Gene1','Gene2']) 
dfdummy=dfdummy.drop({'Corr','Mean.G1/G2'},1).rename(columns={'Gene2':'Previous_gene','Gene1':'Gene'})[['Gene','Path_length','Previous_gene']]
dffinal=dffinal.append(dfdummy)
dffinal=dffinal.drop('Path_length',1) 
dffinal=dffinal.rename(columns={'Gene':'Gene1','Previous_gene':'Gene2'})
if dffinal.shape[0] == 0:
    print("")
    sys.exit("No correlation-based connection between your specified sets of genes. Rerun '[2] Filter_data.py' and try to lower your correlation coefficient threshold value in Filter #4.")

#################################

# Build the whole shortest path network.
shortest_path=dffinal.merge(network_input,on=['Gene1','Gene2'])
dfpositive = shortest_path[shortest_path['Corr'] >= 0]
dfnegative = shortest_path[shortest_path['Corr'] <= 0]
G = nx.from_pandas_edgelist(shortest_path, 'Gene1', 'Gene2')
G.add_edges_from([tuple(x) for x in dfpositive[['Gene1', 'Gene2']].values],color='b')
G.add_edges_from([tuple(x) for x in dfnegative[['Gene1', 'Gene2']].values],color='r')
edges = G.edges()
colors = [G[u][v]['color'] for u,v in edges]
plt.figure()
nx.draw(G, with_labels = True, edges=edges, edge_color=colors)
plt.savefig("Shortest_path_network.png", dpi = 300)

#################################

# Prepare data for numerical analysis.
Etable['Means']=Etable.mean(axis=1)                        # Compute for expression means.
Etable['Max']=np.ceil(Etable.iloc[:, :-1].max(axis=1))     # Compute for rounded up maximum expression.
dffinal=shortest_path.copy()
n=dffinal.shape[0]
m=Etable.shape[0]
dffinal['Means1']=""
dffinal['Means2']=""
dffinal['MaxA']=""
for i in range(n):
    for j in range(m):
        if dffinal.loc[i,'Gene1']==Etable.index[j]:
            dffinal.loc[i,'Means1']=Etable.iloc[j]['Means']
        if dffinal.loc[i,'Gene2']==Etable.index[j]:
            dffinal.loc[i,'Means2']=Etable.iloc[j]['Means']
        if dffinal.loc[i,'Gene1']==Etable.index[j]:
            dffinal.loc[i,'MaxA']=Etable.iloc[j]['Max']

#################################

# Replace gene names with gene IDs.
dffinal=dffinal.sort_values('Gene1',ascending = True)
Etable=Etable['Means']
dups=pd.concat([dffinal.Gene1,dffinal.Gene2]).unique() 
Etable=Etable.loc[Etable.index.isin(dups)].sort_index(ascending = True) 
num_ana_input=dffinal.replace(Etable.index.tolist(),range(1,len(Etable.index)+1))
Etable=Etable.reset_index()
Etable['Gene_ID']=Etable.index+1
gene_ID_ref=Etable.set_index('index')

#################################

# Save shortest path network table. Can be 
# used to create network in other network
# construction software like Cytoscape.
shortest_path = shortest_path.drop("Mean.G1/G2", 1)
shortest_path['test'] = shortest_path.apply(lambda x: '-'.join(sorted([x['Gene1'],x['Gene2']])),axis=1)
shortest_path = shortest_path.drop_duplicates(['test'])
shortest_path.drop(['test'], axis=1, inplace=True)
shortest_path.to_csv('Shortest_path_network.csv', index=False)
print("'Shortest_path_network.csv' saved to " + os.getcwd() + ". (shortest_path)")
print("")

# Save reference of Gene IDs to gene names.
gene_ID_ref.to_csv('Gene_ID_reference.csv', sep = ",",  header = True, index = True)
print("'Gene_ID_reference.csv' saved to " + os.getcwd() + ". (gene_ID_ref)")
print("")

# Save parameters for mathematical model construction and
# numerical analysis.
num_ana_input.to_csv('Numerical_analysis_input.csv', sep = ",",      header = False, index = False)
print("'Numerical_analysis_input.csv' saved to " + os.getcwd() + ". (num_ana_input)")
print("")

# Save parameters for mathematical model construction and
# perturbation analysis.
# Comment out if you do not want to perform perturbation
# analysis.
#################################  
for i in Etable.Gene_ID:
    for j in range(1,16):
        dfperturb=num_ana_input.copy()
        dfperturb.loc[dfperturb['Gene1'] == i, 'Means1'] = j
        dfperturb.loc[dfperturb['Gene2'] == i, 'Means2'] = j
        dfperturb.to_csv('Perturbation_analysis_input_Gene'+str(i)+'_Means'+str(j)+'.csv', sep = ",", header = False, index = False)
        print("'Perturbation_analysis_input_Gene"+str(i)+"_Means"+str(j)+".csv' saved to " + os.getcwd() +".")
        print("")
        del dfperturb
#################################        
        
del Etable, colors, current, currentdistance, dfdum, dfdummy, dffinal, dfnegative, dfpositive, dftable, dups, g, i, j, m, n, neighbordistance, nodes, previous, start, set3, unvisited, visited

#################################

# Display running time.
print("--- %s seconds ---" % (time.time() - start_time))
del start_time