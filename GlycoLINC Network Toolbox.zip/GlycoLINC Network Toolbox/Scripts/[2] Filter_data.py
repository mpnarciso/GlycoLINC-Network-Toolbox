# This code filters the data. It filters
# out genes based on some criteria.
# Code developed by Gilbert Luis F. Gapac
# and Michelle P. Narciso.

#################################

# Import and load needed modules.
import pandas as pd
import numpy as np
import time
import os
pd.options.mode.chained_assignment = None

#################################

# Start running time.
start_time = time.time()

#################################

# Define function for computing the mean expression
# value ratio between genes.
def mean_scoreRatio(transtable):
    mat = transtable.values
    N, K = mat.shape
    result = np.empty((K, K), dtype = np.float64)
    mask = np.isfinite(mat).view(np.uint8)
    for xi in range(K):
    	for yi in range(xi + 1):
    		nobs = sumxx = sumyy = sumx = sumy = 0
    		for i in range(N):
    			if mask[i, xi] and mask[i, yi]:
    				vx = mat[i, xi]
    				vy = mat[i, yi]
    				if vy == 0:
    					vy = .0000001
    				nobs += 1
    				sumx += (vx / vy)   # Compute score ratios.
    				sumy += (vy / vx)
    		meanx = sumx / nobs         # Compute means of score ratios.
    		meany = sumy / nobs
    		result[xi, yi] = meanx	        
    		result[yi, xi] = meany		
    result = pd.DataFrame(result, index = transtable.columns, columns = transtable.columns)
    del K, N, i, mat, meanx, meany, nobs, sumx, sumy, vx, vy, xi, yi, sumxx, sumyy
    return result

#################################
    
# Filter #1:
# Define function for filtering out nearly unexpressed genes.
def rem_lowgenex(mat):
    mat = mat.copy()
    mat['keep'] = mat.mean(axis = 1)
    mat = mat.loc[mat['keep'] >= 1]   # Remove genes with <= 1 mean expression value.
    mat = mat.drop('keep', 1)
    mat.reset_index(inplace = True)
    return mat

#################################

# Filter #2:
# Define function for filtering out gene duplicates.
def rem_dups(mat):    
    dfdups = mat[mat.duplicated('geneSymbol', keep = False) == True]
    dfnotdups = mat.drop_duplicates(subset = 'geneSymbol', keep = False)
    dups = dfdups.set_index('geneSymbol').index[dfdups.set_index('geneSymbol').index.duplicated()].unique()
    dffilt = pd.DataFrame(columns = mat.columns)
    for i in dups:
        dfpart = dfdups.loc[dfdups['geneSymbol'] == i]
        dfpartcor = dfpart.drop('geneSymbol', 1).T.corr(method = 'pearson')
        dfpartcor = dfpartcor.mask(np.triu(np.ones(dfpartcor.shape, dtype = np.bool_)))
        dfpartcor = dfpartcor.stack().reset_index(level = 1).reset_index(level = 0)
        dfpartcor.columns=['Gene1', 'Gene2', 'Corr']
        dfpartcor = dfpartcor[(dfpartcor.Corr >= 0.8)]
        gene = set(dfpartcor.Gene1.append(dfpartcor.Gene2).values)
        dfpart = dfpart[dfpart.index.isin(gene)]
        dffilt = dffilt.append(dfpart)
    dffilt.set_index('geneSymbol',inplace = True)
    dffilt.index.names = ['Gene']
    if dffilt.shape[0] != 0:
        dffilt = dffilt.groupby(level = 'Gene').mean()
    dfnotdups.set_index('geneSymbol',inplace = True)
    dffinal = pd.concat([dfnotdups, dffilt])
    return dffinal

# Define function for not filtering gene duplicates
def remain_dups(mat):
    dfdups = mat[mat.duplicated('geneSymbol', keep = False) == True]
    dfnotdups = mat.drop_duplicates(subset = 'geneSymbol', keep = False)
    dups = dfdups.set_index('geneSymbol').index[dfdups.set_index('geneSymbol').index.duplicated()].unique()
    for i in dups:
        dfpart = dfdups.loc[dfdups['geneSymbol'] == i]
        duplicatedgene = dfpart['geneSymbol'].tolist()
        for j in range(1,len(duplicatedgene) + 1):
            duplicatedgene[j-1] = duplicatedgene[j-1] + "." + str(j)   
        dfpart['geneSymbol'] = duplicatedgene
        dfnotdups = dfnotdups.append(dfpart)
    dfnotdups.set_index('geneSymbol',inplace = True)
    del dfnotdups.index.name
    return dfnotdups

#################################

# Filter #3:
# Define function for filtering out genes with 
# expression values that do not change across
# cell lines (not differentially expressed
# genes. Criterion used: slope.
def slope(mat):
    m = int(input("Please enter the number of replicates in each cell line: "))
    print("")
    print("Your experiments have " + str(m) + " replicate(s).")
    print("")
    print("Filtering out genes with expression values that do not change in all of the samples...")
    print("")
    df = mat.copy()
    mat = df.groupby(np.arange(len(df.columns))//m, axis = 1).mean()
    n = len(mat.columns)
    for i in range(len(mat.columns) - 1):
        mat['Slope' + str(i)] = (mat.iloc[:, i] - mat.iloc[:, i + 1]).abs()
    mat['MaxSlope'] = mat.iloc[:, n:len(mat.columns)].max(axis = 1)
    mat = mat.drop(mat.columns[0: len(mat.columns) - 1], axis = 1)
    df['MaxSlope'] = mat['MaxSlope']
    df = df.drop(df[df.MaxSlope <= 0.05].index)        # Remove genes with <=0.05 maximum slope.
    df = df.drop('MaxSlope', 1)
    return df
   
#################################
    
# Filter #4:
# Define function for filtering out genes without
# strong correlation with any other gene.
def correlation(table, val):
    
    transtable = table.T
    cor_table = transtable.corr(method = 'pearson')
    dfcor = cor_table.mask(np.triu(np.ones(cor_table.shape, dtype = np.bool_)))
    cor_table.columns.name = 'columns'
    dfcor = dfcor.stack().reset_index(level = 1).rename(index = str, columns = {"columns": "Gene2", 0: "Corr"}).reset_index(level = 0).rename(index = str, columns = {"index": "Gene1"})
    dfcor = dfcor.sort_values(['Gene1', 'Gene2'], ascending = [True, True]).reset_index(drop = True)
    df1 = dfcor[(dfcor.Corr >= val) | (dfcor.Corr <= -val)]
    return df1, transtable
 
#################################
    
# Read gene expression matrix.
data = pd.read_csv("Expression_Matrix.csv", index_col = 0)
data.index.names = ['geneSymbol']

#################################

# Implement filters.

#--------------------------------
# Filter #1: unexpressed genes.
print("")
answer = input("Filter #1: Do you wish to filter out unexpressed genes? [yes/no]: ")
print("")
if answer == 'no' or answer == 'NO' or answer == "'no'":
    print("Unexpressed genes NOT filtered out.")
    data_wo_corr = data.reset_index().copy()
else:
    print("Filtering out unexpressed genes...")
    print("")
    data_wo_corr = rem_lowgenex(data)                         
    print("Unexpressed genes filtered out.")
#--------------------------------

#--------------------------------
# Filter #2: gene duplicates.
print("")
answer = input("Filter #2: Do you wish to filter out duplicate probes? [yes/no]: ")
print("")
if answer == 'no' or answer == 'NO' or answer == "'no'":
    print("Duplicate probes NOT filtered out.")
    data_wo_corr = remain_dups(data_wo_corr)
else:
    print("Filtering out duplicate probes...")
    print("")
    data_wo_corr = rem_dups(data_wo_corr)                     
    print("Duplicate probes filtered out.")
#--------------------------------

#--------------------------------
# Filter #3: not differentially expressed genes.
print("")
answer = input("Filter #3: Do you wish to filter out genes with expression values that do not change in all of the samples? [yes/no]: ")
print("")
if answer == 'no' or answer == 'NO' or answer == "'no'":
    print("Genes with expression values that do not change in all of the samples NOT filtered out.")
else:
    data_wo_corr = slope(data_wo_corr)                        
    print("Genes with expression values that do not change in all of the samples filtered out.")
#--------------------------------
    
#--------------------------------
# Filter #4: genes uncorrelated with any other gene.
#            Correlation filter threshold set to 0.9.
print("")
answer = input("Filter #4: Do you wish to filter out genes that are not correlated with any other gene? [yes/no]: ")
print("")
if answer == 'no' or answer == 'NO' or answer == "'no'":
    threshold = 0
    data_w_corr = correlation(data_wo_corr, threshold)[0]
    print("Genes that are not correlated with any other gene NOT filtered out.")
else:
    threshold = float(input("Please provide the correlation threshold value. Press Enter to set default value of 0.9. ") or 0.9)
    print("")
    print("Correlation threshold value set to " + str(threshold) + ".")
    print("")
    print("Filtering out genes that are not correlated with any other gene...")
    print("")
    data_w_corr = correlation(data_wo_corr, threshold)[0]     
    print("Genes that are not correlated with any other gene filtered out.")
print("")
#--------------------------------

#################################

# Prepare data for network analysis, mathematical modeling,
# and perturbation analysis.
transtable = correlation(data_wo_corr, threshold)[1]
meandf = mean_scoreRatio(transtable)
meandf1 = pd.DataFrame(data = meandf.values, index = meandf.index.values, columns = meandf.columns.values)
meandf1.columns.name = 'columns'      
meandf1.index.name = 'geneSymbol'                
meandf = meandf1
                     
# Compute mean ratios.
network_input = data_w_corr.copy()
mean_table_Below = meandf.mask(np.triu(np.ones(meandf.shape, dtype = np.bool)))
mean_table_Below = mean_table_Below.stack().reset_index(level = 1).rename(index = str, columns = {"columns": "Gene2", 0: "Mean.Ratio"}).reset_index(level = 0).rename(index = str, columns = {"geneSymbol": "Gene1"})
mean_table_Below = mean_table_Below.sort_values(['Gene1', 'Gene2'], ascending = [True, True]).reset_index(drop = True)
network_input.loc[:,'Mean.G1/G2'] =  mean_table_Below.loc[network_input.index, 'Mean.Ratio']
mean_table_Above = meandf.mask(np.tril(np.ones(meandf.shape, dtype = np.bool)))
mean_table_Above = mean_table_Above.stack().reset_index(level = 1).rename(index = str, columns = {"columns": "Gene2", 0: "Mean.Ratio"}).reset_index(level = 0).rename(index = str, columns = {"geneSymbol": "Gene1"})
mean_table_Above = mean_table_Above.sort_values(['Gene2', 'Gene1'], ascending = [True, True]).reset_index(drop = True)
network_input.loc[:,'Mean.G2/G1'] = mean_table_Above.loc[network_input.index, 'Mean.Ratio']
del mean_table_Above, mean_table_Below 

# Arrange data in four columns: gene1 name,
# gene2 name, correlation value, mean
# ratio of gene1 over gene2.
es_df1 = network_input[['Gene1', 'Gene2', 'Corr', 'Mean.G1/G2']]
es_df2 = network_input[['Gene2', 'Gene1', 'Corr', 'Mean.G2/G1']]
es_df2.columns = ['Gene1', 'Gene2', 'Corr', 'Mean.G1/G2']
network_input = es_df1.append(es_df2).reset_index(drop = True).sort_values(['Gene1', 'Gene2'], ascending = [True, True]).reset_index(drop = True)
del es_df1, es_df2, meandf, meandf1, transtable, threshold, answer

#################################

# Save filtered data that did not undergo
# through correlation filter. 
data_wo_corr.to_csv("Filtered_data_without_correlation_filter.csv", sep = ",",header = True, index = True)
print("'Filtered_data_without_correlation_filter.csv' saved to " + os.getcwd() + ". (data_wo_corr)")
print("")

# Save filtered data that underwent correlation filter.
data_wo_corr.to_csv("Filtered_data_with_correlation_filter.csv", sep = ",",header = True, index = True)
print("'Filtered_data_with_correlation_filter.csv' saved to " + os.getcwd() + ". (data_w_corr)")
print("")

# Save data for shortest path network input.
network_input.to_csv("Shortest_path_input.csv")
print("'Shortest_path_input.csv' saved to " + os.getcwd() + ". (network_input)")
print("")

#################################

# Display running time.
print("--- %s seconds ---" % (time.time() - start_time))
del start_time