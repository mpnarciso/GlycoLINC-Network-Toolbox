# This code reads and normalize Affymetrix GeneChips
# data into a gene expression matrix.
# Code developed by Gilbert Luis F. Gapac.

###################################
oldw <- getOption("warn")
options(warn = -1)

zz <- file("messages.Rout", open = "wt")
sink(zz, type = "message")
message("not gonna show up in console")

# Install and load needed packages.
if(!require(affy)){
  suppressMessages(source("https://bioconductor.org/biocLite.R"))
  suppressMessages(BiocManager::install("affy"))
  suppressPackageStartupMessages(library(affy))
}
if(!require(rstudioapi)){
  suppressMessages(install.packages("rstudioapi"))
  suppressPackageStartupMessages(library(rstudioapi))
}
if(!require(makecdfenv)){
  suppressMessages(source("http://bioconductor.org/biocLite.R"))
  suppressMessages(BiocManager::install("makecdfenv"))
  suppressPackageStartupMessages(library(makecdfenv))
}
if(!require(Rcpp)){
  suppressMessages(install.packages("Rcpp"))
  suppressPackageStartupMessages(library(Rcpp))
}
if(!require(data.table)){
  suppressMessages(install.packages("data.table"))
  suppressPackageStartupMessages(library(data.table))
}
if(!require(digest)){
  suppressMessages(install.packages("digest"))
  suppressPackageStartupMessages(library(digest))
}
if(!require(AnnotationDbi)){
  suppressMessages(source("http://bioconductor.org/biocLite.R"))
  suppressMessages(BiocManager::install("AnnotationDbi"))
  suppressPackageStartupMessages(library(AnnotationDbi))
}

sink(type="message")
###################################

# Start running time.
start_time <- Sys.time()

###################################

# Replace working directory with the folder containing
# the R script and the .cel files.
celpath <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(celpath)

###################################

# Read .cel files.
data = ReadAffy(celfile.path="./", verbose  = TRUE)

###################################

# Normalize the data.
esetCEL = rma(data)

###################################

# Construct the expression matrix.
E = exprs(esetCEL)

###################################

# Read .annot file.
loadAnnotFile <- function(Filename) {
  temp <- readLines(Filename)       # Load the annotation file.
  temp <- temp[grep("\t", temp)]    # Keep lines with tabs.
  temp <- gsub("\t$", "\tNA", temp) # Deal with NA.
  temp <- strsplit(temp, "\t")      # Split the strings at each tab.
  temp <- t(sapply(temp, unlist))   # Turn each line into a vector then transpose.
  colnames(temp) <- temp[1, ]       # Remove the column names from the data, and return it.
  rownames(temp) <- temp[ ,1]       # Remove the row names from the data, and return it.
  temp[-1, -1]                      # Note that all the entries are strings/characters, not numeric!
}
anntated <- loadAnnotFile(list.files(pattern = "annot"))

###################################

# Get annotated genes.
E <- E[rownames(anntated),]
for(i in rownames(anntated)){
  if (anntated[i, 2] == ""){
    anntated[i, 2] = ((strsplit(i, "[.]"))[[1]])[1]
  }
}
rownames(E) <- anntated[, "Gene symbol"]
rm(i)

###################################

# Export gene expression matrix as a .csv file.
E_table <- as.data.table(E, keep.rownames = TRUE)
View(E_table)
colnames(E_table)[1] = "geneSymbol"
write.table(E_table, file="Expression_Matrix.csv", row.names = FALSE, sep = ',')
print("E_table saved in 'Expression_Matrix.csv'")

###################################

options(warn = oldw)
# Display running time.
end_time <- Sys.time()
cat("Running time: ", end_time - start_time, "seconds")